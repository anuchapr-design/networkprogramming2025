#Step 0: Shared Configuration
# config.py
HOST = "127.0.0.1"
PORT = 6000
BUFFER_SIZE = 1024
