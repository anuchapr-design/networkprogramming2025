#Step 0: Shared Configuration
# config.py
HOST = "127.0.0.1"
BASE_PORT = 8000
PEER_PORTS = [8001, 8002]  # Example peers
BUFFER_SIZE = 1024
RETRY_INTERVAL = 5  # seconds
