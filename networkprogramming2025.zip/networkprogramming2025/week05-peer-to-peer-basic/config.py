# Step 0: Shared Configuration
# config.py
HOST = "127.0.0.1"
BASE_PORT = 9000
BUFFER_SIZE = 1024
