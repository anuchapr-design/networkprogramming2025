# Step 0: Shared Configuration
# config.py
BROADCAST_IP = "192.168.1.3"
PORT = 7000
BUFFER_SIZE = 1024
